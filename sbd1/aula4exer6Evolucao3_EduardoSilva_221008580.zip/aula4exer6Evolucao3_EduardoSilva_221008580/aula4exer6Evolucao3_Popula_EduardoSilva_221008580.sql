-- -------- < aula4exer6Evolucao3 > --------
--
--                    SCRIPT DE INSERCAO (DML)
--
-- Data Criacao ...........: 01/05/2024
-- Autor(es) ..............: Eduardo Belarmino Silva
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: aula4exer6Evolucao3
--
-- 
--
-- ---------------------------------------------------------

USE aula4exer6Evolucao3;

-- Inserção de dados na tabela UF
INSERT INTO UF (sigla, nome) VALUES
('SP', 'São Paulo'),
('RJ', 'Rio de Janeiro'),
('MG', 'Minas Gerais'),
('RS', 'Rio Grande do Sul'),
('BA', 'Bahia'),
('PR', 'Paraná');

-- Inserção de dados na tabela CATEGORIA
INSERT INTO CATEGORIA (categoria) VALUES
('Passeio'),
('Comercial'),
('Transporte'),
('Especial'),
('Oficial'),
('Coleção');

-- Inserção de dados na tabela MODELO
INSERT INTO MODELO (modelo) VALUES
('Civic'),
('Corolla'),
('Fusca'),
('Celta'),
('Palio'),
('Gol');

-- Inserção de dados na tabela TIPOINFRACAO
INSERT INTO TIPOINFRACAO (descricaoInfracao, valorInfracao) VALUES
('Excesso de velocidade até 20%', 130.50),
('Excesso de velocidade entre 21% e 50%', 195.75),
('Estacionamento irregular', 100.00),
('Avanço de sinal', 150.00),
('Uso de celular', 175.25),
('Direção perigosa', 300.00);

-- Inserção de dados na tabela AGENTE
INSERT INTO AGENTE (matricula, nome, dataDeContratacao) VALUES
('AG001', 'João Silva', '2018-05-21'),
('AG002', 'Maria Souza', '2019-06-15'),
('AG003', 'Carlos Prado', '2017-07-10'),
('AG004', 'Ana Lima', '2019-08-20'),
('AG005', 'Ricardo Mendes', '2020-01-30'),
('AG006', 'Fernanda Gomes', '2018-12-19');

-- Inserção de dados na tabela LOCALINFRACAO
INSERT INTO LOCALINFRACAO (latitude, longitude, velocidadePermitida) VALUES
('23.5505', '-46.6333', 50),
('22.9068', '-43.1729', 60),
('19.9245', '-43.9352', 70),
('30.0346', '-51.2177', 80),
('12.9714', '-38.5014', 90),
('25.4284', '-49.2733', 100);

-- Inserção de dados na tabela ENDERECO
INSERT INTO ENDERECO (logradouro, complemento, bairro, cidade, uf) VALUES
('Rua das Flores', 'Apto 101', 'Centro', 'São Paulo', 'SP'),
('Avenida Brasil', 'Casa 20', 'Jardim América', 'Rio de Janeiro', 'RJ'),
('Praça da Liberdade', '', 'Savassi', 'Belo Horizonte', 'MG'),
('Rua dos Andradas', 'Sala 304', 'Centro Histórico', 'Porto Alegre', 'RS'),
('Avenida Sete de Setembro', '', 'Comércio', 'Salvador', 'BA'),
('Rua XV de Novembro', 'Loja 1', 'Centro', 'Curitiba', 'PR');

-- Inserção de dados na tabela PROPRIETARIO
INSERT INTO PROPRIETARIO (cpf, nome, idEndereco, sexo, dataDeNascimento) VALUES
('12345678901', 'Lucas Moraes', 1, 'Masculino', '1990-04-25'),
('98765432109', 'Julia Carvalho', 2, 'Feminino', '1985-08-15'),
('55544433322', 'Marcos Teixeira', 3, 'Masculino', '1972-11-30'),
('22233344455', 'Carla Dias', 4, 'Feminino', '1995-05-21'),
('11122233344', 'Roberto Almeida', 5, 'Masculino', '1988-02-10'),
('66677788899', 'Patrícia Nobrega', 6, 'Feminino', '1978-07-07');

-- Inserção de dados na tabela VEICULO
INSERT INTO VEICULO (placa, chassi, cor, idProprietario, idModelo, idCategoria, anoDeFabricacao) VALUES
('XYZ1234', 'CHASSI001', 'Preto', 1, 1, 1, 2015),
('ABC5678', 'CHASSI002', 'Branco', 2, 2, 2, 2016),
('DEF9012', 'CHASSI003', 'Vermelho', 3, 3, 3, 2017),
('GHI3456', 'CHASSI004', 'Azul', 4, 4, 4, 2018),
('JKL7890', 'CHASSI005', 'Verde', 5, 5, 5, 2019),
('MNO1234', 'CHASSI006', 'Amarelo', 6, 6, 6, 2020);

-- Inserção de dados na tabela INFRACAO
INSERT INTO INFRACAO (tipoInfracao, idVeiculo, horario, localInfracao, velocidadeAferida, agenteDeTransito) VALUES
(1, 1, '2024-05-10 14:00:00', 1, 55, 'AG001'),
(2, 2, '2024-05-11 09:30:00', 2, 70, 'AG002'),
(3, 3, '2024-05-12 16:45:00', 3, 75, 'AG003'),
(4, 4, '2024-05-13 08:15:00', 4, 85, 'AG004'),
(5, 5, '2024-05-14 19:30:00', 5, 95, 'AG005'),
(6, 6, '2024-05-15 22:00:00', 6, 105, 'AG006');

-- Inserção de dados na tabela TELEFONE
INSERT INTO TELEFONE (ddi, ddd, numero, idProprietario) VALUES
(55, 11, 987654321, 1),
(55, 21, 123456789, 2),
(55, 31, 234567890, 3),
(55, 51, 345678901, 4),
(55, 71, 456789012, 5),
(55, 41, 567890123, 6);

