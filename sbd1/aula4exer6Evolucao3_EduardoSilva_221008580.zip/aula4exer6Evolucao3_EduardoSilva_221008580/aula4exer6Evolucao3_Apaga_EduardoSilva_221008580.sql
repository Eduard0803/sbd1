-- -------- < aula4exer6Evolucao3 > --------
--
--                    SCRIPT DE REMOCAO (DML)
--
-- Data Criacao ...........: 01/05/2024
-- Autor(es) ..............: Eduardo Belarmino Silva
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: aula4exer6Evolucao3
--
-- 
-- Ultimas Alteracoes
--      08/05/2024 => Mudança do método de limpeza de dados de "DROP DATABASE" para "DROP TABLE" individual em cada tabela.
--
--
-- ---------------------------------------------------------

USE aula4exer6Evolucao3;

DROP TABLE TELEFONE;
DROP TABLE INFRACAO;
DROP TABLE VEICULO;
DROP TABLE PROPRIETARIO;
DROP TABLE ENDERECO;
DROP TABLE AGENTE;
DROP TABLE UF;
DROP TABLE MODELO;
DROP TABLE LOCALINFRACAO;
DROP TABLE TIPOINFRACAO;
DROP TABLE CATEGORIA;
