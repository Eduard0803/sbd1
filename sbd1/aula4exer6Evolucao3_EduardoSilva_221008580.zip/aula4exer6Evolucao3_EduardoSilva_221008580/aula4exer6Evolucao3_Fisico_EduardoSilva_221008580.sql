-- -------- < aula4exer6Evolucao3 > --------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 01/05/2024
-- Autor(es) ..............: Eduardo Belarmino Silva
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: aula4exer6Evolucao3
--
-- PROJETO => 01 Base de Dados
--         => 11 Tabelas
-- 
-- Ultimas Alteracoes
--      06/05/2024 => Adição de if not exists na criação da base de dados.
--      06/05/2024 => Adição de ENGINE = InnoDB em todas as tabelas.
--      08/05/2024 => Remodelagem do esquema de todas as tabelas.
--                 => Adição de auto-incremento nas chaves primarias.
--      13/05/2024 => Adição chaves candidatas quando necessário.
--
-- ---------------------------------------------------------

CREATE DATABASE 
  IF NOT EXISTS aula4exer6Evolucao3;
USE aula4exer6Evolucao3;

CREATE TABLE CATEGORIA (
    id INT AUTO_INCREMENT,
    categoria VARCHAR(100) NOT NULL,
    CONSTRAINT CATEGORIA_PK PRIMARY KEY (id),
    CONSTRAINT CATEGORIA_categoria_UK UNIQUE (categoria)
) ENGINE = InnoDB;

CREATE TABLE TIPOINFRACAO (
    id INT AUTO_INCREMENT,
    descricaoInfracao VARCHAR(100) NOT NULL,
    valorInfracao DECIMAL(10,2) NOT NULL,
    CONSTRAINT TIPOINFRACAO_PK PRIMARY KEY (id),
    CONSTRAINT TIPOINFRACAO_descricaoInfracao_UK UNIQUE (descricaoInfracao)
) ENGINE = InnoDB;

CREATE TABLE LOCALINFRACAO (
    id int AUTO_INCREMENT,
    latitude VARCHAR(100) NOT NULL,
    longitude VARCHAR(100) NOT NULL,
    velocidadePermitida INT NOT NULL,
    CONSTRAINT LOCALINFRACAO_PK PRIMARY KEY (id),
    CONSTRAINT LOCALINFRACAO_latitude_longitude_UK UNIQUE (latitude, longitude, velocidadePermitida)
) ENGINE = InnoDB;

CREATE TABLE MODELO (
    id int AUTO_INCREMENT,
    modelo VARCHAR(100) NOT NULL,
    CONSTRAINT MODELO_PK PRIMARY KEY (id),
    CONSTRAINT MODELO_modelo_UK UNIQUE (modelo)
) ENGINE = InnoDB;

CREATE TABLE UF (
    sigla CHAR(2),
    nome VARCHAR(100) NOT NULL,
    CONSTRAINT UF_PK PRIMARY KEY (sigla),
    CONSTRAINT UF_nome_UK UNIQUE (nome),
    CONSTRAINT UF_sigla_nome_UK UNIQUE (sigla, nome)
) ENGINE = InnoDB;

CREATE TABLE AGENTE (
    matricula VARCHAR(100),
    nome VARCHAR(100) NOT NULL,
    dataDeContratacao DATE NOT NULL,
    CONSTRAINT AGENTE_PK PRIMARY KEY (matricula)
) ENGINE = InnoDB;

CREATE TABLE ENDERECO (
    id int AUTO_INCREMENT,
    logradouro VARCHAR(100) NOT NULL,
    complemento VARCHAR(100),
    bairro VARCHAR(100) NOT NULL,
    cidade VARCHAR(100) NOT NULL,
    uf CHAR(2) NOT NULL,
    CONSTRAINT ENDERECO_PK PRIMARY KEY (id),
    CONSTRAINT ENDERECO_UF_FK FOREIGN KEY (uf) REFERENCES UF(sigla)
) ENGINE = InnoDB;

CREATE TABLE PROPRIETARIO (
    id int AUTO_INCREMENT,
    cpf VARCHAR(11) NOT NULL,
    nome VARCHAR(100) NOT NULL,
    idEndereco INT NOT NULL,
    sexo VARCHAR(10) NOT NULL,
    dataDeNascimento DATE NOT NULL,
    CONSTRAINT PROPRIETARIO_PK PRIMARY KEY (id),
    CONSTRAINT PROPRIETARIO_ENDERECO_FK FOREIGN KEY (idEndereco) REFERENCES ENDERECO(id),
    CONSTRAINT PROPRIETARIO_cpf_UK UNIQUE (cpf)
) ENGINE = InnoDB;

CREATE TABLE VEICULO (
    placa VARCHAR(7) NOT NULL,
    chassi VARCHAR(17) NOT NULL,
    cor VARCHAR(100) NOT NULL,
    id int AUTO_INCREMENT,
    idProprietario INT NOT NULL,
    idModelo INT NOT NULL,
    idCategoria INT NOT NULL,
    anoDeFabricacao INT NOT NULL,
    CONSTRAINT VEICULO_PK PRIMARY KEY (id),
    CONSTRAINT VEICULO_PROPRIETARIO_FK FOREIGN KEY (idProprietario) REFERENCES PROPRIETARIO(id),
    CONSTRAINT VEICULO_MODELO_FK FOREIGN KEY (idModelo) REFERENCES MODELO(id),
    CONSTRAINT VEICULO_CATEGORIA_FK FOREIGN KEY (idCategoria) REFERENCES CATEGORIA(id),
    CONSTRAINT VEICULO_placa_UK UNIQUE (placa),
    CONSTRAINT VEICULO_chassi_UK UNIQUE (chassi)
) ENGINE = InnoDB;

CREATE TABLE INFRACAO (
    id int AUTO_INCREMENT,
    tipoInfracao INT NOT NULL,
    idVeiculo INT NOT NULL,
    horario DATETIME NOT NULL,
    localInfracao INT NOT NULL,
    velocidadeAferida INT NOT NULL,
    agenteDeTransito VARCHAR(100) NOT NULL,
    CONSTRAINT INFRACAO_PK PRIMARY KEY (id),
    CONSTRAINT INFRACAO_TIPOINFRACAO_FK FOREIGN KEY (tipoInfracao) REFERENCES TIPOINFRACAO(id),
    CONSTRAINT INFRACAO_VEICULO_FK FOREIGN KEY (idVeiculo) REFERENCES VEICULO(id),
    CONSTRAINT INFRACAO_LOCALINFRACAO_FK FOREIGN KEY (localInfracao) REFERENCES LOCALINFRACAO(id),
    CONSTRAINT INFRACAO_AGENTE_FK FOREIGN KEY (agenteDeTransito) REFERENCES AGENTE(matricula)
) ENGINE = InnoDB;

CREATE TABLE TELEFONE (
    ddi int NOT NULL,
    ddd int NOT NULL,
    numero int NOT NULL,
    idProprietario INT NOT NULL,
    CONSTRAINT TELEFONE_PROPRIETARIO_FK FOREIGN KEY (idProprietario) REFERENCES PROPRIETARIO(id),
    CONSTRAINT TELEFONE_ddi_ddd_numero_UK UNIQUE (ddi, ddd, numero)
) ENGINE = InnoDB;
