--
-- -------- < aula6exer4 Fisico > --------
--
--                    SCRIPT DE REMOÇÃO (DML)
--
-- Data Criacao ...........: 29/05/2024
-- Autor(es) ..............: Eduardo Belarmino Silva
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: aula6exer4
--
--
-- 
--
-- ---------------------------------------------------------


USE aula6exer4;

-- Populando a tabela PESSOA
INSERT INTO PESSOA (nome, dataDeNascimento, sexo) VALUES
('João Silva', '1980-03-15', 'M'),
('Maria Oliveira', '1985-07-22', 'F'),
('Carlos Santos', '1990-12-10', 'M'),
('Ana Souza', '1978-05-30', 'F');

-- Populando a tabela EMPREGADO
INSERT INTO EMPREGADO (matricula, salario, rua, bairro, numero, idPessoa, idDepartamento, idSupervisor) VALUES
('MAT001', 3000.00, 'Rua A', 'Bairro 1', 123, 1, 1, NULL),
('MAT002', 4000.00, 'Rua B', 'Bairro 2', 456, 2, 2, 1),
('MAT003', 3500.00, 'Rua C', 'Bairro 3', 789, 3, 3, 2),
('MAT004', 3200.00, 'Rua D', 'Bairro 4', 101, 4, 4, 1);

-- Populando a tabela GERENTE
INSERT INTO GERENTE (idEmpregado, inicioGerencia) VALUES
(1, '2020-01-01'),
(2, '2021-02-01'),
(3, '2019-03-01'),
(4, '2022-04-01');

-- Populando a tabela DEPENDENTE
INSERT INTO DEPENDENTE (idPessoa, idEmpregado) VALUES
(1, 2),
(2, 1),
(3, 3),
(4, 4);

-- Populando a tabela DEPARTAMENTO
INSERT INTO DEPARTAMENTO (nome, inicioGerencia, idGerente) VALUES
('Departamento A', '2020-01-01', 1),
('Departamento B', '2021-02-01', 2),
('Departamento C', '2019-03-01', 3),
('Departamento D', '2022-04-01', 4);

-- Populando a tabela PROJETO
INSERT INTO PROJETO (nome, localizacao, idDepartamento) VALUES
('Projeto Alpha', 'Local 1', 1),
('Projeto Beta', 'Local 2', 2),
('Projeto Gamma', 'Local 3', 3),
('Projeto Delta', 'Local 4', 4);

-- Populando a tabela EMPREGADO_PROJETO_trabalha
INSERT INTO EMPREGADO_PROJETO_trabalha (idEmpregado, idProjeto, horasTrabalhadas) VALUES
(1, 1, 20.5),
(2, 2, 35.0),
(3, 3, 40.0),
(4, 4, 25.0);

-- Populando a tabela localizacao
INSERT INTO localizacao (idDepartamento, localizacao) VALUES
(1, 'Local 1'),
(2, 'Local 2'),
(3, 'Local 3'),
(4, 'Local 4');
