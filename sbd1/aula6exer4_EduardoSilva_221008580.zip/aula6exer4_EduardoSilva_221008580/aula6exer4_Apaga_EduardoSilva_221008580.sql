--
-- -------- < aula6exer4 Fisico > --------
--
--                    SCRIPT DE REMOÇÃO (DML)
--
-- Data Criacao ...........: 29/05/2024
-- Autor(es) ..............: Eduardo Belarmino Silva
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: aula6exer4
--
--
-- 
--
-- ---------------------------------------------------------


USE aula6exer4;

DROP TABLE localizacao;
DROP TABLE EMPREGADO_PROJETO_trabalha;
DROP TABLE PROJETO;
DROP TABLE DEPARTAMENTO;
DROP TABLE DEPENDENTE;
DROP TABLE GERENTE;
DROP TABLE EMPREGADO;
DROP TABLE PESSOA;
