-- --------     << TF_1A_brunooliveira >>     ------------
--
--                    SCRIPT DE CONTROLE (DDL)
--
-- Data Criacao ...........: 14/06/2024
-- Autor(es) ..............: BRUNO OLIVEIRA, EDUARDO SILVA, CARLOS ALVES
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: TF_1A_brunooliveira
--
--
-- PROJETO => 01 Base de Dados
--         => 14 Tabelas
--         => 03 Visoes
--         => 03 Perfis (role)
--         => 09 Usuarios
--
-- ULTIMAS ALTERACOES => 21/06/24 - Autor: Bruno Oliveira
--                          1. Adicionando mais um User para Role Consultora (Joana)
--                          2. Adicionando mais um User para Role Cliente (Carlos)
--
--                    => 24/06/24 - Autor: Carlos Alves
--                          1. Criando o Perfil Administrador 
--                          2. Adicao dos usuarios 'Carla', 'Wagner' e 'Pedro' com o Perfil Administrador
-- 
-- -----------------------------------

-- CRIACAO DO PERFIL ADMINISTRADOR
CREATE ROLE 'Administrador';
GRANT ALL PRIVILEGES ON *.* TO 'Administrador' WITH GRANT OPTION;

CREATE USER 'Carla'@'localhost' IDENTIFIED BY 'password1';
CREATE USER 'Wagner'@'localhost' IDENTIFIED BY 'password2';
CREATE USER 'Pedro'@'localhost' IDENTIFIED BY 'password3';

GRANT 'Administrador' TO 'Carla'@'localhost';
GRANT 'Administrador' TO 'Wagner'@'localhost';
GRANT 'Administrador' TO 'Pedro'@'localhost';

SET DEFAULT ROLE 'Administrador' TO 'Carla'@'localhost';
SET DEFAULT ROLE 'Administrador' TO 'Wagner'@'localhost';
SET DEFAULT ROLE 'Administrador' TO 'Pedro'@'localhost';

-- CRIACAO DO PERFIL CONSULTORA
CREATE ROLE 'Consultora';
GRANT INSERT, SELECT, UPDATE, DELETE ON TF_1A_brunooliveira.* TO Consultora;

CREATE USER 'Leticia'@'localhost' IDENTIFIED BY 'senhaLeticia';
CREATE USER 'Maria'@'localhost' IDENTIFIED BY 'senhaMaria';
CREATE USER 'Joana'@'localhost' IDENTIFIED BY 'senhaJoana';

GRANT Consultora TO Leticia@'localhost';
GRANT Consultora TO Maria@'localhost';
GRANT Consultora TO Joana@'localhost';

SET DEFAULT ROLE 'Consultora' TO 'Leticia'@'localhost';
SET DEFAULT ROLE 'Consultora' TO 'Maria'@'localhost';
SET DEFAULT ROLE 'Consultora' TO 'Joana'@'localhost';

-- CRIACAO DO PERFIL CLIENTE
CREATE ROLE 'Cliente';
GRANT SELECT ON TF_1A_brunooliveira.ESTOQUE TO Cliente;

CREATE USER 'Marina'@'localhost' IDENTIFIED BY 'senhaMarina';
CREATE USER 'Ana'@'localhost' IDENTIFIED BY 'senhaAna';
CREATE USER 'Carlos'@'localhost' IDENTIFIED BY 'senhaCarlos';

GRANT Cliente TO Marina@'localhost';
GRANT Cliente TO Ana@'localhost';
GRANT Cliente TO Carlos@'localhost';

SET DEFAULT ROLE 'Cliente' TO 'Marina'@'localhost';
SET DEFAULT ROLE 'Cliente' TO 'Ana'@'localhost';
SET DEFAULT ROLE 'Cliente' TO 'Carlos'@'localhost';

FLUSH PRIVILEGES;
