-- --------     << TF_1A_brunooliveira >>     ------------
--
--                    SCRIPT DE INSERCAO (DML)
--
-- Data Criacao ...........: 02/06/2024
-- Autor(es) ..............: BRUNO OLIVEIRA, EDUARDO SILVA, CARLOS ALVES
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: TF_1A_brunooliveira
--
--
-- PROJETO => 01 Base de Dados
--         => 14 Tabelas
--         => 03 Visoes
--         => 03 Perfis (role)
--         => 09 Usuarios
--
-- -- ULTIMAS ALTERACOES => 15/06/24 - Autor: Eduardo Silva
--                          1. Insercao do atributo 'taxaProcessamento' em METODOS_DE_PAGAMENTO
--                          2. Insercao do atributo 'sexo' em PRODUTO
--                          3. Insercao do atributo 'sexo' em CLIENTE
--                          5. Insercao do atributo 'statusVenda' em VENDA
--
--                    => 21/06/24 - Autor: Bruno Oliveira
--                          1. Adicionando mais 5 tuplas de Método de Pagamento
--                          2. Adicionando mais 5 tuplas de Cliente 
--                          3. Adicionando mais 5 tuplas de Marca 
--                          4. Adicionando mais 5 tuplas de Categoria 
--                          5. Adicionando mais 5 tuplas de Produto
--                          6. Adicionando mais 5 tuplas de Venda 
--                          7. Adicionando mais 5 tuplas de Item de Venda 
--                          8. Adicionando mais 5 tuplas de Pagamento de Venda 
--                          9. Adicionando mais 5 tuplas de Pedido 
--                          10. Adicionando mais 5 tuplas de Item de Pedido (Espuma de Barbear, Creme Facial Anti-Idade, Creme para Mãos Lavanda, Protetor Solar FPS 50, Máscara Capilar Revitalizante)
--                          11. Adicionando mais 5 tuplas de Telefone (Elena Costa, Fernando Lima, Gabriela Pereira, Hugo Alves, Iara Mendes)
--       
--                  => 24/06/24 - Autor: Carlos Alves
--                  		1. Adicionando situacao de venda
--                  		2. colocando as situacao nas vendas

-- -----------------------------------

USE TF_1A_brunooliveira;

-- Inserção na tabela METODOS_DE_PAGAMENTO
INSERT INTO METODOS_DE_PAGAMENTO (descricao, taxaProcessamento) VALUES 
('Cartão de Crédito', 2),
('Boleto Bancário', 0),
('PIX', 0),
('Transferência Bancária', 0),
('Dinheiro', 0),
('PayPal', 3),
('Apple Pay', 2),
('Google Pay', 2),
('Cheque', 1),
('Vale Alimentação', 0);

-- Inserção na tabela CLIENTE
INSERT INTO CLIENTE (nomeCliente, cidade, rua, bairro, numero, uf, sexo) VALUES 
('Ana Silva', 'Brasília', 'Rua 3C Chácara 28', 'Setor Habitacional Vicente Pires', 705, 'DF', 'F'),
('Bruno Oliveira', 'Brasília', 'Quadra 110 Conjunto 1', 'Samambaia', 728, 'DF', 'M'),
('Carlos Souza', 'Brasília', 'Quadra CLS 209 Bloco B', 'Asa Sul', 417, 'DF', 'M'),
('Daniela Santos', 'Brasília', 'Quadra QNM 20 Conjunto D', 'Ceilândia Norte (Ceilândia)', 247, 'DF', 'F'),
('Kauê Assunção', 'Brasília', 'Quadra QN 507 Conjunto 5', 'Samambaia Sul (Samambaia)', 119, 'DF', 'M'),
('Elena Costa', 'São Paulo', 'Avenida Paulista', 'Bela Vista', 1578, 'SP', 'F'),
('Fernando Lima', 'São Paulo', 'Rua Augusta', 'Consolação', 1300, 'SP', 'M'),
('Gabriela Pereira', 'Rio de Janeiro', 'Avenida das Nações', 'Parque das Nações', 300, 'RJ', 'F'),
('Hugo Alves', 'Rio de Janeiro', 'Rua das Flores', 'Jardim Botânico', 520, 'RJ', 'M'),
('Iara Mendes', 'Rio de Janeiro', 'Avenida Atlântica', 'Copacabana', 123, 'RJ', 'F');

-- Inserção na tabela MARCA
INSERT INTO MARCA (nomeMarca, email) VALUES 
('Natura', 'comercial@natura.com.br'),
('Jequiti', 'comercial@jequiti.com.br'),
('oBoticário', 'comercial@oboticario.com.br'),
('Mary Kay', 'comercial@marykay.com.br'),
('Eudora', 'comercial@eudora.com.br'),
('Avon', 'comercial@avon.com.br'),
('Vult', 'comercial@vult.com.br'),
('LOccitane', 'comercial@br.loccitane.com'),
('Granado', 'comercial@granado.com.br'),
('Dove', 'comercial@dove.com');

-- Inserção na tabela CATEGORIA
INSERT INTO CATEGORIA (nomeCategoria) VALUES 
('Perfume'),
('Maquiagem'),
('Cabelos'),
('Hidratante Corporal'),
('Corpo e Banho'),
('Barba'),
('Rosto'),
('Mãos e Pés'),
('Protetor Solar'),
('Tratamento Capilar');

-- Inserção na tabela PRODUTO
INSERT INTO PRODUTO (idMarca, idCategoria, nomeProduto, sexo) VALUES 
(1, 1, 'Kaiak Masculino', 'M'),
(2, 2, 'Batom Matte Ellas Jequiti', 'F'),
(3, 3, 'Shampoo Vegano Ultra Hidratação Nativa Spa Karité 300ml', 'U'),
(4, 4, 'Loção Corporal Firmadora Targeted-Action® TimeWise 3D', 'F'),
(5, 5, 'Body Spray Desodorante Imensi 100ml', 'F'),
(6, 6, 'Espuma de Barbear', 'M'),
(7, 7, 'Creme Facial Anti-Idade', 'F'),
(8, 8, 'Creme para Mãos Lavanda', 'F'),
(9, 9, 'Protetor Solar FPS 50', 'U'),
(10, 10, 'Máscara Capilar Revitalizante', 'U');

-- Inserção na tabela SITUACAO_VENDA
INSERT INTO SITUACAO_VENDA (nomeStatus) VALUES
('Pendente'),
('Processando'),
('Enviado'),
('Entregue'),
('Cancelado'),
('Devolvido'),
('Aguardando Pagamento'),
('Pagamento Confirmado'),
('Preparando para Envio'),
('Aguardando Retirada');

-- Inserção na tabela VENDA
INSERT INTO VENDA (idCliente, dataDaVenda, idStatus) VALUES 
(1, '2024-02-05', 1),
(2, '2024-03-06', 2),
(3, '2024-03-07', 3),
(4, '2024-03-08', 4),
(5, '2024-04-09', 5),
(6, '2024-04-10', 6),
(7, '2024-05-11', 7),
(8, '2024-05-12', 8),
(9, '2024-06-13', 9),
(10, '2024-06-14', 10);

-- Inserção na tabela ITEM_VENDA
INSERT INTO ITEM_VENDA (idVenda, idProduto, qtdProdutos, precoUnitario, precoUnitarioMedioPedido) VALUES 
(1, 1, 2, 10.00, 6.00),
(2, 2, 1, 20.00, 12.00),
(3, 3, 3, 30.00, 18.00),
(4, 4, 2, 40.00, 24.00),
(5, 5, 6, 40.00, 24.00),
(6, 6, 2, 15.00, 9.00),
(7, 7, 1, 25.00, 15.00),
(8, 8, 3, 12.00, 7.50),
(9, 9, 1, 50.00, 30.00),
(10, 10, 2, 35.00, 21.00);

-- Inserção na tabela PAGAMENTO_VENDA
INSERT INTO PAGAMENTO_VENDA (idVenda, idMetodoPagamento) VALUES 
(1, 1),
(2, 2),
(3, 3),
(4, 4),
(5, 3),
(6, 5),
(7, 6),
(8, 7),
(9, 8),
(10, 9);

-- Inserção na tabela PEDIDO
INSERT INTO PEDIDO (dataDaCompra) VALUES 
('2024-01-15'),
('2024-02-15'),
('2024-03-15'),
('2024-04-15'),
('2024-05-15'),
('2024-06-15'),
('2024-07-15'),
('2024-08-15'),
('2024-09-15'),
('2024-10-15');

-- Inserção na tabela ITEM_PEDIDO
INSERT INTO ITEM_PEDIDO (idPedido, idProduto, qtdProdutos, precoUnitario, dataDeValidade) VALUES 
(1, 1, 2, 10.00, '2025-03-24'),
(2, 2, 1, 20.00, '2024-07-25'),
(3, 3, 3, 30.00, '2025-12-28'),
(4, 4, 4, 40.00, '2024-11-02'),
(5, 5, 10, 39.99, '2026-06-19'),
(5, 4, 10, 39.99, '2023-06-19'),
(6, 6, 5, 15.00, '2025-01-01'),
(7, 7, 2, 25.00, '2024-12-31'),
(8, 8, 6, 12.00, '2025-05-15'),
(9, 9, 3, 50.00, '2024-11-20'),
(10, 10, 4, 35.00, '2025-10-10');

-- Inserção na tabela TELEFONE
INSERT INTO telefoneCliente (idCliente, ddd, numero) VALUES 
(1, '61', '987654321'),
(2, '61', '987654322'),
(3, '61', '987654323'),
(4, '61', '987654324'),
(5, '61', '993982665'),
(6, '11', '987654326'),
(7, '11', '987654327'),
(8, '21', '987654328'),
(9, '21', '987654329'),
(10, '21', '987654330');

-- Inserção na tabela parcela
INSERT INTO parcela (idPagamentoVenda, valorParcela, dataVencimento) VALUES 
(1, 5.00, '2024-06-05'),
(2, 20.00, '2024-06-06'),
(3, 10.00, '2024-06-07'),
(4, 20.00, '2024-06-08'),
(5, 30.00, '2024-06-09'),
(6, 10.00, '2024-06-10'),
(7, 25.00, '2024-06-11'),
(8, 5.00, '2024-06-12'),
(9, 50.00, '2024-06-13'),
(10, 35.00, '2024-06-14');

-- Inserção na tabela TELEFONEMARCA
INSERT INTO telefoneMarca (idMarca, ddd, numero) VALUES 
(1, '11', '987654321'),
(2, '21', '987654322'),
(3, '31', '987654323'),
(4, '41', '987654324'),
(5, '51', '987654325'),
(6, '61', '987654326'),
(7, '71', '987654327'),
(8, '81', '987654328'),
(9, '91', '987654329'),
(10, '11', '987654330');
