-- =====     aula1exer2     =====
--
--                    SCRIPT DE REMOCAO (DDL)
--
-- Data Criacao ...........: 31/03/2025
-- Autor(es) ..............: Eduardo Belarmino Silva
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: aula1exer2
--
-- PROJETO => 01 Base de Dados
--         => 08 Tabelas
-- 
-- ---------------------------------------------------------

USE aula1exer2;

DROP TABLE VENDA_ITEM;
DROP TABLE PRODUTO;
DROP TABLE VENDA;
DROP TABLE supervisiona;
DROP TABLE telefone_empregado;
DROP TABLE EMPREGADO;
DROP TABLE GERENTE;
DROP TABLE PESSOA;
