-- =====     aula1exer2     =====
--
--                    SCRIPT DE INSERCAO (DDL)
--
-- Data Criacao ...........: 31/03/2025
-- Autor(es) ..............: Eduardo Belarmino Silva
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: aula1exer2
--
-- PROJETO => 01 Base de Dados
--         => 08 Tabelas
-- 
-- ---------------------------------------------------------
USE aula1exer2;

INSERT INTO PESSOA (cpf, nome, senha) VALUES
('12345678901', 'Ana Souza', 'senha'),
('23456789012', 'Bruno Lima', 'senha'),
('34567890123', 'Carlos Alberto', 'senha'),
('45678901234', 'Daniela Costa', 'senha'),
('56789012345', 'Eduardo Silva', 'senha'),
('67890123456', 'Fernanda Rocha', 'senha'),
('78901234567', 'Gabriel Martins', 'senha'),
('89012345678', 'Helena Dias', 'senha'),
('90123456789', 'Igor Ferreira', 'senha'),
('01234567890', 'Juliana Mendes', 'senha');

INSERT INTO GERENTE (email, cpf, formacao_escolar) VALUES
('ana.souza@empresa.com', '12345678901', 'superior'),
('bruno.lima@empresa.com', '23456789012', 'medio'),
('carlos.alberto@empresa.com', '34567890123', 'superior'),
('daniela.costa@empresa.com', '45678901234', 'fundamental'),
('eduardo.silva@empresa.com', '56789012345', 'medio');

INSERT INTO EMPREGADO (matricula, cpf, uf, cidade, bairro, logradouro, complemento) VALUES
('EMP001', '67890123456', 'SP', 'São Paulo', 'Bela Vista', 'Rua A', 'Apto 101'),
('EMP002', '78901234567', 'RJ', 'Rio de Janeiro', 'Copacabana', 'Avenida Atlântica', NULL),
('EMP003', '89012345678', 'MG', 'Belo Horizonte', 'Savassi', 'Rua B', 'Fundos'),
('EMP004', '90123456789', 'RS', 'Porto Alegre', 'Centro', 'Rua C', 'Sala 4'),
('EMP005', '01234567890', 'BA', 'Salvador', 'Barra', 'Rua D', NULL);

INSERT INTO telefone_empregado (matricula_empregado, ddd, numero) VALUES
('EMP001', '11', 987654321),
('EMP002', '21', 998877665),
('EMP003', '31', 912345678),
('EMP004', '51', 934567890),
('EMP005', '71', 976543210);

INSERT INTO supervisiona (email, matricula) VALUES
('ana.souza@empresa.com', 'EMP001'),
('bruno.lima@empresa.com', 'EMP002'),
('carlos.alberto@empresa.com', 'EMP003'),
('daniela.costa@empresa.com', 'EMP004'),
('eduardo.silva@empresa.com', 'EMP005');

INSERT INTO VENDA (matricula_empregado, data_venda) VALUES
('EMP001', '2025-03-01 10:30:00'),
('EMP002', '2025-03-02 14:15:00'),
('EMP003', '2025-03-03 11:45:00'),
('EMP004', '2025-03-04 16:00:00'),
('EMP005', '2025-03-05 13:20:00');

INSERT INTO PRODUTO (nome) VALUES
('Notebook Dell Inspiron'),
('Smartphone Samsung Galaxy'),
('Mouse Logitech'),
('Monitor LG 24"'),
('Teclado Mecânico Redragon');

INSERT INTO VENDA_ITEM (id_venda, id_produto, preco_unitario, quantidade) VALUES
(1, 1, 3500.00, 1),
(2, 2, 2500.00, 2),
(3, 3, 150.00, 3),
(4, 4, 1200.00, 1),
(5, 5, 300.00, 2);
