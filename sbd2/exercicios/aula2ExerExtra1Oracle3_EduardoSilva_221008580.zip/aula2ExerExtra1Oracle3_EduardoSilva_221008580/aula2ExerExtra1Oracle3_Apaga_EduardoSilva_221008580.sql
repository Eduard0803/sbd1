-- =====     << Aula2 - Exercicio Extra 1 - Evolucao 2 >>     =====
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criação ...........: 25/04/2025
-- Autor(es) ..............: Lucas Felipe Soares, Brunno Fernandes Franco, Eduardo Belarmino Silva
-- Banco de Dados .........: Oracle Database 19c EE Extreme Perf Release 19.0.0.0.0
-- Base de Dados (nome) ...: aula2ExerExtra1
--
-- PROJETO => 01 Base de Dados
--         => 08 Tabelas
--
-- ULTIMAS ATUALIZACOES
--   01/05/2025 => Ajustes na apresentacao da documentacao desse script.
--              => Remocao de 'IF EXISTS' de todos os comandos.
--              => Exclusao da linha que apagava a tabela possui (que nao existe mais no projeto).
--              => Inclusao dos comandos para apagar os perfis (roles).
--              => Inclusao dos comandos para apagar os usuarios (users).
--              
--   12/05/2025 => Alteração do script para adequar ao Oracle Apex.
--                  => Remoção do 'USE aula2ExerExtra1'.
--                  => Remoção dos comandos DROP ROLE.
--                  => Remoção dos comandos DROP USER.
--              => Adição do prefixo 'EBS_' nos nomes das tabelas.
--
-- ----------------------------------------------------------------------------------------------------


DROP TABLE EBS_tem;
DROP TABLE EBS_telefone;
DROP TABLE EBS_RECEITA;
DROP TABLE EBS_CONSULTA;
DROP TABLE EBS_MEDICAMENTO;
DROP TABLE EBS_PACIENTE;
DROP TABLE EBS_MEDICO;
DROP TABLE EBS_ESPECIALIDADE;
