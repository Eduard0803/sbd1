-- =====     << Aula2 - Exercicio Extra 1 - Evolucao 2 >>     =====
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criação ...........: 25/04/2025
-- Autor(es) ..............: Lucas Felipe Soares, Brunno Fernandes Franco, Eduardo Belarmino Silva
-- Banco de Dados .........: Oracle Database 19c EE Extreme Perf Release 19.0.0.0.0
-- Base de Dados (nome) ...: aula2ExerExtra1
--
-- PROJETO => 01 Base de Dados
--         => 08 Tabelas
--
-- ULTIMAS ATUALIZACOES
--   01/05/2025 => Ajustes na apresentacao da documentacao desse script.
--              => Exclusao do comando para popular a tabela possui (que nao existe mais no projeto).
--              => Ajustes nas tuplas de todas as tabelas, levando-se em conta o auto_increment
--                 nas tabelas ESPECIALIDADE, PACIENTE, CONSULTA, RECEITA e MEDICAMENTO;
--              => Alteracao nas tuplas existentes, incluindo dados mais proximos da realidade.
--              => Inclusao de novas tuplas em todas as tabelas.
--              
--   12/05/2025 => Alteração do script para adequar ao Oracle Apex.
--                  => Remoção do 'USE aula2ExerExtra1'.
--                  => Adição da função TO_DATE ao inserir dataNascimento na tabela EBS_PACIENTE.
--                  => Adição da função TO_DATE ao inserir dataConsulta na tabela EBS_CONSULTA.
--                  => Adição da função TO_DATE ao inserir horaConsulta na tabela EBS_CONSULTA.
--                  => Adição de um INSERT INTO para cada tupla a ser inserida.
--              => Adição do prefixo 'EBS_' nos nomes das tabelas.
--
-- ------------------------------------------------------------------------------------------------------


INSERT INTO EBS_ESPECIALIDADE (nomeEspecialidade) VALUES ('Clínico Geral');
INSERT INTO EBS_ESPECIALIDADE (nomeEspecialidade) VALUES ('Cardiologia');
INSERT INTO EBS_ESPECIALIDADE (nomeEspecialidade) VALUES ('Pediatria');
INSERT INTO EBS_ESPECIALIDADE (nomeEspecialidade) VALUES ('Gastroenterologia');
INSERT INTO EBS_ESPECIALIDADE (nomeEspecialidade) VALUES ('Neurologia');
INSERT INTO EBS_ESPECIALIDADE (nomeEspecialidade) VALUES ('Psiquiatria');
INSERT INTO EBS_ESPECIALIDADE (nomeEspecialidade) VALUES ('Oftalmologia');
INSERT INTO EBS_ESPECIALIDADE (nomeEspecialidade) VALUES ('Endocrinologia');
INSERT INTO EBS_ESPECIALIDADE (nomeEspecialidade) VALUES ('Urologia');
INSERT INTO EBS_ESPECIALIDADE (nomeEspecialidade) VALUES ('Dermatologia');


INSERT INTO EBS_MEDICO (numeroCrm, unidadeFederativa, nomeMedico, idEspecialidade) VALUES (15432, 'DF', 'Dr. Lucas Andrade', 1);
INSERT INTO EBS_MEDICO (numeroCrm, unidadeFederativa, nomeMedico, idEspecialidade) VALUES (17895, 'DF', 'Dra. Fernanda Souza', 2);
INSERT INTO EBS_MEDICO (numeroCrm, unidadeFederativa, nomeMedico, idEspecialidade) VALUES (16348, 'DF', 'Dr. Marcelo Pereira', 3);
INSERT INTO EBS_MEDICO (numeroCrm, unidadeFederativa, nomeMedico, idEspecialidade) VALUES (19257, 'DF', 'Dra. Aline Costa', 4);
INSERT INTO EBS_MEDICO (numeroCrm, unidadeFederativa, nomeMedico, idEspecialidade) VALUES (18764, 'DF', 'Dr. Paulo Mendes', 5);
INSERT INTO EBS_MEDICO (numeroCrm, unidadeFederativa, nomeMedico, idEspecialidade) VALUES (17529, 'DF', 'Dra. Marina Vieira', 6);
INSERT INTO EBS_MEDICO (numeroCrm, unidadeFederativa, nomeMedico, idEspecialidade) VALUES (16487, 'DF', 'Dr. Rafael Almeida', 7);
INSERT INTO EBS_MEDICO (numeroCrm, unidadeFederativa, nomeMedico, idEspecialidade) VALUES (19321, 'DF', 'Dra. Camila Torres', 8);
INSERT INTO EBS_MEDICO (numeroCrm, unidadeFederativa, nomeMedico, idEspecialidade) VALUES (18276, 'DF', 'Dr. Gustavo Rocha', 9);
INSERT INTO EBS_MEDICO (numeroCrm, unidadeFederativa, nomeMedico, idEspecialidade) VALUES (16894, 'DF', 'Dra. Patrícia Martins', 10);


INSERT INTO EBS_PACIENTE (nome, sexo, dataNascimento, rua, numero, complemento, bairro, cidade, estado, cep) VALUES ('Ana Beatriz Silva', 'F', TO_DATE('2000-04-12', 'YYYY-MM-DD'), 'SQN 106', 12, 'Bloco A', 'Asa Norte', 'Brasília', 'DF', '70740-500');
INSERT INTO EBS_PACIENTE (nome, sexo, dataNascimento, rua, numero, complemento, bairro, cidade, estado, cep) VALUES ('Bruno Henrique Costa', 'M', TO_DATE('1993-07-08', 'YYYY-MM-DD'), 'SQS 211', 45, 'Bloco D', 'Asa Sul', 'Brasília', 'DF', '70293-150');
INSERT INTO EBS_PACIENTE (nome, sexo, dataNascimento, rua, numero, complemento, bairro, cidade, estado, cep) VALUES ('Carla Mendes Lopes', 'F', TO_DATE('1996-11-03', 'YYYY-MM-DD'), 'CLN 204', 78, 'Bloco B', 'Asa Norte', 'Brasília', 'DF', '70853-020');
INSERT INTO EBS_PACIENTE (nome, sexo, dataNascimento, rua, numero, complemento, bairro, cidade, estado, cep) VALUES ('Daniel Souza Rocha', 'M', TO_DATE('1984-01-17', 'YYYY-MM-DD'), 'QI 25', 123, 'Casa 5', 'Lago Sul', 'Brasília', 'DF', '71675-250');
INSERT INTO EBS_PACIENTE (nome, sexo, dataNascimento, rua, numero, complemento, bairro, cidade, estado, cep) VALUES ('Elisa Campos Farias', 'F', TO_DATE('1988-09-22', 'YYYY-MM-DD'), 'QE 15', 256, 'Bloco 18', 'Guará II', 'Brasília', 'DF', '71025-060');
INSERT INTO EBS_PACIENTE (nome, sexo, dataNascimento, rua, numero, complemento, bairro, cidade, estado, cep) VALUES ('Felipe Gomes Santos', 'M', TO_DATE('2003-05-10', 'YYYY-MM-DD'), 'QN 3', 89, 'Ap 102', 'Riacho Fundo I', 'Brasília', 'DF', '71820-030');
INSERT INTO EBS_PACIENTE (nome, sexo, dataNascimento, rua, numero, complemento, bairro, cidade, estado, cep) VALUES ('Gabriela Duarte Lima', 'F', TO_DATE('1994-06-18', 'YYYY-MM-DD'), 'QS 08', 54, 'Lote 10', 'Águas Claras', 'Brasília', 'DF', '71955-360');
INSERT INTO EBS_PACIENTE (nome, sexo, dataNascimento, rua, numero, complemento, bairro, cidade, estado, cep) VALUES ('Henrique Moraes Cardoso', 'M', TO_DATE('1996-08-27', 'YYYY-MM-DD'), 'SHIN CA 05', 70, 'Casa 32', 'Lago Norte', 'Brasília', 'DF', '71505-000');
INSERT INTO EBS_PACIENTE (nome, sexo, dataNascimento, rua, numero, complemento, bairro, cidade, estado, cep) VALUES ('Isabela Freitas Cunha', 'F', TO_DATE('1989-12-30', 'YYYY-MM-DD'), 'CLSW 101', 9, 'Bloco B', 'Sudoeste', 'Brasília', 'DF', '70673-200');
INSERT INTO EBS_PACIENTE (nome, sexo, dataNascimento, rua, numero, complemento, bairro, cidade, estado, cep) VALUES ('João Victor Ribeiro', 'M', TO_DATE('1998-03-21', 'YYYY-MM-DD'), 'SQSW 300', 200, 'Bloco H', 'Sudoeste', 'Brasília', 'DF', '70687-310');


INSERT INTO EBS_telefone (idPaciente, telefone) VALUES (101, '5561999123456');
INSERT INTO EBS_telefone (idPaciente, telefone) VALUES (102, '5561999876543');
INSERT INTO EBS_telefone (idPaciente, telefone) VALUES (103, '5561998765432');
INSERT INTO EBS_telefone (idPaciente, telefone) VALUES (104, '5561997785642');
INSERT INTO EBS_telefone (idPaciente, telefone) VALUES (105, '5561999651234');
INSERT INTO EBS_telefone (idPaciente, telefone) VALUES (106, '5561997541236');
INSERT INTO EBS_telefone (idPaciente, telefone) VALUES (107, '5561998642351');
INSERT INTO EBS_telefone (idPaciente, telefone) VALUES (108, '5561996784512');
INSERT INTO EBS_telefone (idPaciente, telefone) VALUES (109, '5561999456213');
INSERT INTO EBS_telefone (idPaciente, telefone) VALUES (110, '5561997321465');


INSERT INTO EBS_MEDICAMENTO (nomeMedicamento, principioAtivo, posologia) VALUES ('Losartana 50mg', 'Losartana', 'Tomar 1 comprimido ao dia');
INSERT INTO EBS_MEDICAMENTO (nomeMedicamento, principioAtivo, posologia) VALUES ('Amoxicilina 500mg', 'Amoxicilina', 'Tomar 1 cápsula a cada 8h');
INSERT INTO EBS_MEDICAMENTO (nomeMedicamento, principioAtivo, posologia) VALUES ('Ibuprofeno 600mg', 'Ibuprofeno', 'Tomar 1 comprimido se tiver dor');
INSERT INTO EBS_MEDICAMENTO (nomeMedicamento, principioAtivo, posologia) VALUES ('Omeprazol 20mg', 'Omeprazol', 'Tomar 1 cápsula em jejum');
INSERT INTO EBS_MEDICAMENTO (nomeMedicamento, principioAtivo, posologia) VALUES ('Amitriptilina 25mg', 'Amitriptilina', 'Tomar 1 antes de dormir');
INSERT INTO EBS_MEDICAMENTO (nomeMedicamento, principioAtivo, posologia) VALUES ('Paracetamol 750mg', 'Paracetamol', 'Tomar 1 comprimido se tiver febre');
INSERT INTO EBS_MEDICAMENTO (nomeMedicamento, principioAtivo, posologia) VALUES ('Sertralina 50mg', 'Sertralina', 'Tomar 1 comprimido diário');
INSERT INTO EBS_MEDICAMENTO (nomeMedicamento, principioAtivo, posologia) VALUES ('Colírio Systane', 'Polietilenoglicol', 'Aplicar 2 gotas em cada olho 4x/dia');
INSERT INTO EBS_MEDICAMENTO (nomeMedicamento, principioAtivo, posologia) VALUES ('Tamsulosina 0,4mg', 'Tamsulosina', 'Tomar 1 comprimido após jantar');
INSERT INTO EBS_MEDICAMENTO (nomeMedicamento, principioAtivo, posologia) VALUES ('Metformina 850mg', 'Metformina', 'Tomar 1 no almoço e jantar');
INSERT INTO EBS_MEDICAMENTO (nomeMedicamento, principioAtivo, posologia) VALUES ('Vitamina D 2000UI', 'Colecalciferol', 'Tomar 1 cápsula diária');
INSERT INTO EBS_MEDICAMENTO (nomeMedicamento, principioAtivo, posologia) VALUES ('Pantoprazol 40mg', 'Pantoprazol', 'Tomar 1 comprimido antes do café');
INSERT INTO EBS_MEDICAMENTO (nomeMedicamento, principioAtivo, posologia) VALUES ('Fluoxetina 20mg', 'Fluoxetina', 'Tomar 1 cápsula pela manhã');


INSERT INTO EBS_CONSULTA (numeroCrm, unidadeFederativa, idPaciente, dataConsulta, horaConsulta) VALUES (15432, 'DF', 101, TO_DATE('2025-04-01', 'YYYY-MM-DD'), TO_DATE('08:00:00', 'HH24:MI:SS'));
INSERT INTO EBS_CONSULTA (numeroCrm, unidadeFederativa, idPaciente, dataConsulta, horaConsulta) VALUES (15432, 'DF', 102, TO_DATE('2025-04-03', 'YYYY-MM-DD'), TO_DATE('09:00:00', 'HH24:MI:SS'));
INSERT INTO EBS_CONSULTA (numeroCrm, unidadeFederativa, idPaciente, dataConsulta, horaConsulta) VALUES (16348, 'DF', 103, TO_DATE('2025-04-02', 'YYYY-MM-DD'), TO_DATE('10:00:00', 'HH24:MI:SS'));
INSERT INTO EBS_CONSULTA (numeroCrm, unidadeFederativa, idPaciente, dataConsulta, horaConsulta) VALUES (19257, 'DF', 104, TO_DATE('2025-04-05', 'YYYY-MM-DD'), TO_DATE('11:00:00', 'HH24:MI:SS'));
INSERT INTO EBS_CONSULTA (numeroCrm, unidadeFederativa, idPaciente, dataConsulta, horaConsulta) VALUES (18764, 'DF', 105, TO_DATE('2025-04-07', 'YYYY-MM-DD'), TO_DATE('14:00:00', 'HH24:MI:SS'));
INSERT INTO EBS_CONSULTA (numeroCrm, unidadeFederativa, idPaciente, dataConsulta, horaConsulta) VALUES (17529, 'DF', 106, TO_DATE('2025-04-08', 'YYYY-MM-DD'), TO_DATE('15:00:00', 'HH24:MI:SS'));
INSERT INTO EBS_CONSULTA (numeroCrm, unidadeFederativa, idPaciente, dataConsulta, horaConsulta) VALUES (17529, 'DF', 107, TO_DATE('2025-04-08', 'YYYY-MM-DD'), TO_DATE('16:00:00', 'HH24:MI:SS'));
INSERT INTO EBS_CONSULTA (numeroCrm, unidadeFederativa, idPaciente, dataConsulta, horaConsulta) VALUES (17529, 'DF', 108, TO_DATE('2025-04-09', 'YYYY-MM-DD'), TO_DATE('08:00:00', 'HH24:MI:SS'));
INSERT INTO EBS_CONSULTA (numeroCrm, unidadeFederativa, idPaciente, dataConsulta, horaConsulta) VALUES (16487, 'DF', 109, TO_DATE('2025-04-10', 'YYYY-MM-DD'), TO_DATE('09:30:00', 'HH24:MI:SS'));
INSERT INTO EBS_CONSULTA (numeroCrm, unidadeFederativa, idPaciente, dataConsulta, horaConsulta) VALUES (19321, 'DF', 110, TO_DATE('2025-04-10', 'YYYY-MM-DD'), TO_DATE('10:00:00', 'HH24:MI:SS'));
INSERT INTO EBS_CONSULTA (numeroCrm, unidadeFederativa, idPaciente, dataConsulta, horaConsulta) VALUES (15432, 'DF', 101, TO_DATE('2025-04-15', 'YYYY-MM-DD'), TO_DATE('08:30:00', 'HH24:MI:SS'));
INSERT INTO EBS_CONSULTA (numeroCrm, unidadeFederativa, idPaciente, dataConsulta, horaConsulta) VALUES (19257, 'DF', 104, TO_DATE('2025-04-20', 'YYYY-MM-DD'), TO_DATE('10:45:00', 'HH24:MI:SS'));
INSERT INTO EBS_CONSULTA (numeroCrm, unidadeFederativa, idPaciente, dataConsulta, horaConsulta) VALUES (17529, 'DF', 107, TO_DATE('2025-04-22', 'YYYY-MM-DD'), TO_DATE('14:15:00', 'HH24:MI:SS'));


INSERT INTO EBS_RECEITA (idConsulta) VALUES (10001);
INSERT INTO EBS_RECEITA (idConsulta) VALUES (10002);
INSERT INTO EBS_RECEITA (idConsulta) VALUES (10003);
INSERT INTO EBS_RECEITA (idConsulta) VALUES (10004);
INSERT INTO EBS_RECEITA (idConsulta) VALUES (10005);
INSERT INTO EBS_RECEITA (idConsulta) VALUES (10006);
INSERT INTO EBS_RECEITA (idConsulta) VALUES (10007);
INSERT INTO EBS_RECEITA (idConsulta) VALUES (10008);
INSERT INTO EBS_RECEITA (idConsulta) VALUES (10009);
INSERT INTO EBS_RECEITA (idConsulta) VALUES (10010);
INSERT INTO EBS_RECEITA (idConsulta) VALUES (10011);
INSERT INTO EBS_RECEITA (idConsulta) VALUES (10012);
INSERT INTO EBS_RECEITA (idConsulta) VALUES (10013);


INSERT INTO EBS_tem (idReceita, idMedicamento) VALUES (50001, 100001);
INSERT INTO EBS_tem (idReceita, idMedicamento) VALUES (50002, 100002);
INSERT INTO EBS_tem (idReceita, idMedicamento) VALUES (50003, 100003);
INSERT INTO EBS_tem (idReceita, idMedicamento) VALUES (50004, 100004);
INSERT INTO EBS_tem (idReceita, idMedicamento) VALUES (50005, 100005);
INSERT INTO EBS_tem (idReceita, idMedicamento) VALUES (50006, 100006);
INSERT INTO EBS_tem (idReceita, idMedicamento) VALUES (50007, 100007);
INSERT INTO EBS_tem (idReceita, idMedicamento) VALUES (50008, 100008);
INSERT INTO EBS_tem (idReceita, idMedicamento) VALUES (50009, 100009);
INSERT INTO EBS_tem (idReceita, idMedicamento) VALUES (50010, 100010);
INSERT INTO EBS_tem (idReceita, idMedicamento) VALUES (50011, 100011);
INSERT INTO EBS_tem (idReceita, idMedicamento) VALUES (50012, 100012);
INSERT INTO EBS_tem (idReceita, idMedicamento) VALUES (50013, 100013);
