-- -------- < aula4exer6 > --------
--
--                    SCRIPT DE INSERCAO (DML)
--
-- Data Criacao ...........: 01/05/2024
-- Autor(es) ..............: Eduardo Belarmino Silva
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: aula4exer6Evolucao2
--
-- 
--
-- ---------------------------------------------------------

USE aula4exer6Evolucao2;

-- Populando a tabela CATEGORIA
INSERT INTO CATEGORIA (categoria) VALUES ('Categoria A'), ('Categoria B'), ('Categoria C');

-- Populando a tabela TIPOINFRACAO
INSERT INTO TIPOINFRACAO (descricaoInfracao, valorInfracao) VALUES 
('Excesso de Velocidade', 150.00), 
('Estacionamento Irregular', 100.00), 
('Ultrapassagem Proibida', 200.00);

-- Populando a tabela LOCALINFRACAO
INSERT INTO LOCALINFRACAO (latitude, longitude, velocidadePermitida) VALUES 
('40.7128° N', '74.0060° W', 60), 
('34.0522° N', '118.2437° W', 50), 
('51.5074° N', '0.1278° W', 70);

-- Populando a tabela MODELO
INSERT INTO MODELO (modelo) VALUES ('Modelo X'), ('Modelo Y'), ('Modelo Z');

-- Populando a tabela UF
INSERT INTO UF (sigla, nome) VALUES ('SP', 'São Paulo'), ('RJ', 'Rio de Janeiro'), ('MG', 'Minas Gerais');

-- Populando a tabela AGENTE
INSERT INTO AGENTE (matricula, nome, dataDeContratacao, tempoDeServico) VALUES 
('123456', 'João Silva', '2020-01-15', 4), 
('789012', 'Maria Oliveira', '2018-05-20', 6), 
('345678', 'José Santos', '2017-10-10', 8);

-- Populando a tabela ENDERECO
INSERT INTO ENDERECO (logradouro, complemento, bairro, cidade, uf) VALUES 
('Rua A', 'Apt 101', 'Centro', 'São Paulo', 'SP'), 
('Avenida B', 'Casa 20', 'Copacabana', 'Rio de Janeiro', 'RJ'), 
('Rua C', 'Sobrado 5', 'Santo Antônio', 'Belo Horizonte', 'MG');

-- Populando a tabela PROPRIETARIO
INSERT INTO PROPRIETARIO (cpf, nome, idEndereco, sexo, dataDeNascimento) VALUES 
('12345678901', 'Ana Souza', 1, 'Feminino', '1980-03-12'), 
('98765432109', 'Carlos Oliveira', 2, 'Masculino', '1975-07-25'), 
('45678912307', 'Mariana Santos', 3, 'Feminino', '1992-11-30');

-- Populando a tabela VEICULO
INSERT INTO VEICULO (idProprietario, idModelo, idCategoria) VALUES 
(1, 1, 1), 
(2, 2, 2), 
(3, 3, 3);

-- Populando a tabela INFRACAO
INSERT INTO INFRACAO (tipoInfracao, idVeiculo, horario, localInfracao, velocidadeAferida, agenteDeTransito) VALUES 
(1, 1, '2024-05-01 08:30:00', 1, 80, '123456'), 
(2, 2, '2024-05-02 10:45:00', 2, 65, '789012'), 
(3, 3, '2024-05-03 14:20:00', 3, 90, '345678');

-- Populando a tabela TELEFONE
INSERT INTO TELEFONE (ddi, ddd, numero, idProprietario) VALUES 
(55, 11, 912345678, 1), 
(55, 21, 987654321, 2), 
(55, 31, 876543210, 3);
