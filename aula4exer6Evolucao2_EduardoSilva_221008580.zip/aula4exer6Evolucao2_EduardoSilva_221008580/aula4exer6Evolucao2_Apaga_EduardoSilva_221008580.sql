-- -------- < aula4exer6 > --------
--
--                    SCRIPT DE REMOCAO (DML)
--
-- Data Criacao ...........: 01/05/2024
-- Autor(es) ..............: Eduardo Belarmino Silva
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: aula4exer6Evolucao2
--
-- 
--
-- ---------------------------------------------------------

DROP DATABASE aula4exer6Evolucao2;
