-- -------- < aula4exer6 > --------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 01/05/2024
-- Autor(es) ..............: Larissa de Jesus Vieira
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: aula4exer6Evolucao2
--
-- PROJETO => 01 Base de Dados
--         => 11 Tabelas
--         => 00 Visoes
--         => 00 Perfis (role)
--         => 00 Usuarios
--         => 00 Sequencias
--         => 00 Triggers
--         => 00 Procedimentos
--         => 00 Funcoes

-- 
-- Ultimas Alteracoes
    -- (06/05) - atualizacao do esquema de tabelas. autor: Eduardo Belarmino Silva
--
-- ---------------------------------------------------------
CREATE DATABASE aula4exer6Evolucao2;
USE aula4exer6Evolucao2;

CREATE TABLE CATEGORIA (
    id INT AUTO_INCREMENT PRIMARY KEY,
    categoria VARCHAR(100) NOT NULL
);

CREATE TABLE TIPOINFRACAO (
    id INT AUTO_INCREMENT PRIMARY KEY,
    descricaoInfracao VARCHAR(100) NOT NULL,
    valorInfracao DECIMAL(10,2) NOT NULL
);

CREATE TABLE LOCALINFRACAO (
    id int AUTO_INCREMENT PRIMARY KEY,
    latitude VARCHAR(100) NOT NULL,
    longitude VARCHAR(100) NOT NULL,
    velocidadePermitida INT NOT NULL
);

CREATE TABLE MODELO (
    id int AUTO_INCREMENT PRIMARY KEY,
    modelo VARCHAR(100) NOT NULL
);

CREATE TABLE UF (
    sigla CHAR(2) PRIMARY KEY,
    nome VARCHAR(100) NOT NULL
);

CREATE TABLE AGENTE (
    matricula VARCHAR(100) PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    dataDeContratacao DATE NOT NULL,
    tempoDeServico INT NOT NULL
);

CREATE TABLE ENDERECO (
    id int AUTO_INCREMENT PRIMARY KEY,
    logradouro VARCHAR(100) NOT NULL,
    complemento VARCHAR(100) NOT NULL,
    bairro VARCHAR(100) NOT NULL,
    cidade VARCHAR(100) NOT NULL,
    uf CHAR(2) NOT NULL,
    FOREIGN KEY (uf) REFERENCES UF(sigla)
);

CREATE TABLE PROPRIETARIO (
    id int AUTO_INCREMENT PRIMARY KEY,
    cpf VARCHAR(11) NOT NULL,
    nome VARCHAR(100) NOT NULL,
    idEndereco INT NOT NULL,
    sexo VARCHAR(10) NOT NULL,
    dataDeNascimento DATE NOT NULL,
    FOREIGN KEY (idEndereco) REFERENCES ENDERECO(id)
);


CREATE TABLE VEICULO (
    id int AUTO_INCREMENT PRIMARY KEY,
    idProprietario INT NOT NULL,
    idModelo INT NOT NULL,
    idCategoria INT NOT NULL,
    FOREIGN KEY (idProprietario) REFERENCES PROPRIETARIO(id),
    FOREIGN KEY (idModelo) REFERENCES MODELO(id),
    FOREIGN KEY (idCategoria) REFERENCES CATEGORIA(id)
);

CREATE TABLE INFRACAO (
    id int AUTO_INCREMENT PRIMARY KEY,
    tipoInfracao INT NOT NULL,
    idVeiculo INT NOT NULL,
    horario DATETIME NOT NULL,
    localInfracao INT NOT NULL,
    velocidadeAferida INT NOT NULL,
    agenteDeTransito VARCHAR(100) NOT NULL,
    FOREIGN KEY (tipoInfracao) REFERENCES TIPOINFRACAO(id),
    FOREIGN KEY (idVeiculo) REFERENCES VEICULO(id),
    FOREIGN KEY (localInfracao) REFERENCES LOCALINFRACAO(id),
    FOREIGN KEY (agenteDeTransito) REFERENCES AGENTE(matricula)
);

CREATE TABLE TELEFONE (
    ddi int NOT NULL,
    ddd int NOT NULL,
    numero int NOT NULL,
    idProprietario INT NOT NULL,
    FOREIGN KEY (idProprietario) REFERENCES PROPRIETARIO(id)
);
